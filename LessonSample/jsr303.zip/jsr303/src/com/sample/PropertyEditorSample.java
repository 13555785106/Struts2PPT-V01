package com.sample;

import java.beans.BeanInfo;
import java.beans.Introspector;
import java.beans.PropertyDescriptor;
import java.beans.PropertyEditor;
import java.beans.PropertyEditorManager;
import java.lang.reflect.Array;
import java.lang.reflect.Method;
import java.util.HashMap;
import java.util.Map;

import com.sample.propeditor.DateEditor;

public class PropertyEditorSample {
	static {
		PropertyEditorManager.registerEditor(java.util.Date.class, DateEditor.class);
	}

	public static void main(String[] args) throws Exception {

		Map<String, String> parameters = new HashMap<String, String>();
		parameters.put("account", "sa");
		parameters.put("passwd", "123");
		parameters.put("sex", "男");
		parameters.put("salary", "5555.88");
		parameters.put("birthday", "1973-10-11 02:30:59");
		parameters.put("hobbies", "足球,篮球,排球");
		System.out.println(convert("1973-10-11 02:30:59", java.util.Date.class));
		User user = convert(parameters, User.class);
		System.out.println(user);

	}


	@SuppressWarnings("unchecked")
	private static <T> T convert(String str, Class<T> clazz) {
		T val = null;
		PropertyEditor editor = PropertyEditorManager.findEditor(clazz);
		if (editor != null) {
			editor.setAsText(str);
			val= (T) editor.getValue();
		}
		return val;
	}

	private static <T> T convert(Map<String, String> parameters, Class<T> clazz) throws Exception {
		T val = clazz.newInstance();
		BeanInfo bi = Introspector.getBeanInfo(clazz);
		PropertyDescriptor[] pds = bi.getPropertyDescriptors();
		for (PropertyDescriptor pd : pds) {
			System.out.println("[" + pd.getName() + "]");
			String paramValue = parameters.get(pd.getName());
			Class<?> propertyType = pd.getPropertyType();
			Method writeMethod = pd.getWriteMethod();
			if (propertyType == String.class) {
				writeMethod.invoke(val, paramValue);
			}
			if (propertyType.isArray()) {
				String[] strs = paramValue.split(",");
				if (strs != null) {
					Object o = Array.newInstance(propertyType.getComponentType(), strs.length);
					for(int i=0;i<strs.length;i++) {
						Array.set(o, i, strs[i]);
					}
					writeMethod.invoke(val, o);
				}
			} else {
				PropertyEditor editor = PropertyEditorManager.findEditor(propertyType);
				if (editor != null) {
					editor.setAsText(parameters.get(pd.getName()));
					writeMethod.invoke(val, editor.getValue());
				} else {
					System.out.println("no editor for:" + pd.getName());
				}
			}
		}
		return val;
	}
}
