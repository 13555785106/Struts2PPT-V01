package com.sample;

import java.lang.reflect.Constructor;
import java.lang.reflect.InvocationTargetException;
import java.lang.reflect.Method;
import java.util.Date;
import java.util.Set;

import javax.validation.Configuration;
import javax.validation.ConstraintViolation;
import javax.validation.Validation;
import javax.validation.Validator;
import javax.validation.ValidatorFactory;
import javax.validation.executable.ExecutableValidator;
import org.apache.log4j.Logger;
import org.hibernate.validator.HibernateValidator;

public class UserValidatorTest {
	static Logger log = Logger.getLogger(UserValidatorTest.class);

	public static void main(String[] args) throws NoSuchMethodException, SecurityException {
		testValidateBean();
		// testValidateParam();
		// testValidateReturnValue();
		// testValidateConstructor();
		//testValidateByXml();
	}

	public static void pringValidateStr(Set<ConstraintViolation<User>> cvSet) {
		for (ConstraintViolation<User> constraintViolation : cvSet) {
			log.info("字段：" + constraintViolation.getPropertyPath().toString());
			log.info("无效值：" + constraintViolation.getInvalidValue());
			log.info("错误：" + constraintViolation.getMessage());
		}
	}

	public static void testValidateBean() {
		User user = new User();
		user.setAccount("sa");
		user.setPasswd("123");
		user.setSex("男女");
		user.setSalary(90000.0);
		user.setBirthday(new Date());

		ValidatorFactory validatorFactory = Validation.buildDefaultValidatorFactory();
		Validator validator = validatorFactory.getValidator();
		Set<ConstraintViolation<User>> set = validator.validate(user);
		for (ConstraintViolation<User> constraintViolation : set) {
			System.out.println("字段：" + constraintViolation.getPropertyPath().toString());
			System.out.println("错误：" + constraintViolation.getMessage());
		}
	}

	public static void testValidateParam() throws NoSuchMethodException, SecurityException {
		ValidatorFactory factory = Validation.buildDefaultValidatorFactory();
		// 1.获取校验器
		Validator validator = factory.getValidator();

		// 2.获取校验方法参数的校验器
		ExecutableValidator validatorParam = validator.forExecutables();
		// 3 创建一个要校验参数的实例
		User user = new User(null, null);
		// 4 获取要校验的方法
		Method method = User.class.getMethod("getCommission", Float.class);
		// 传递校验参数的输入的参数
		Object[] paramObjects = new Object[] { 2f };
		// 开始校验
		Set<ConstraintViolation<User>> constraintViolationSet = validatorParam.validateParameters(user, method,
				paramObjects);
		for (ConstraintViolation<User> item : constraintViolationSet) {
			log.info(item.getMessage());
		}
	}

	public static void testValidateReturnValue() throws NoSuchMethodException, SecurityException {
		ValidatorFactory factory = Validation.buildDefaultValidatorFactory();
		// 1.获取校验器
		Validator validator = factory.getValidator();

		// 2.获取校验方法参数的校验器
		ExecutableValidator validatorParam = validator.forExecutables();
		// 3 创建一个要校验参数的实例
		User user = new User(null, null);
		// 4 获取要校验的方法
		Method method = User.class.getMethod("getCommission", Float.class);
		// 传递校验参数的输入的参数
		Object[] paramObjects = new Object[] { 2f };
		Object returnValue = null;
		try {
			returnValue = method.invoke(user, paramObjects);// 调用方法获取返回值
		} catch (IllegalAccessException e) {
			e.printStackTrace();
		} catch (InvocationTargetException e) {
			e.printStackTrace();
		}
		// 5.校验返回值
		Set<ConstraintViolation<User>> constraintViolationSet = validatorParam.validateReturnValue(user, method,
				returnValue);
		for (ConstraintViolation<User> item : constraintViolationSet) {
			log.info(item.getMessage());
		}
	}

	public static void testValidateConstructor() throws NoSuchMethodException {
		ValidatorFactory factory = Validation.buildDefaultValidatorFactory();
		// 1.获取校验器
		Validator validator = factory.getValidator();
		// 2.获取校验方法参数的校验器
		ExecutableValidator validatorParam = validator.forExecutables();
		// 3.获取构造函数
		Constructor<User> constructor = User.class.getConstructor(String.class, String.class);
		Object[] constructorsParams = new Object[] { null, null };
		Set<ConstraintViolation<User>> constraintViolationSet = validatorParam
				.validateConstructorParameters(constructor, constructorsParams);
		for (ConstraintViolation<User> item : constraintViolationSet) {
			log.info(item.getMessage());
		}
	}

	public static void testValidateByXml() {
		User user = new User();
		// user.setAccount("sa");
		user.setPasswd("123");
		user.setSex("女0");
		user.setSalary(90000.0);
		user.setBirthday(new Date());
		user.setHobbies(new String[] { "aaa" });
		Configuration<?> configuration = Validation.byDefaultProvider().configure();
		configuration.addMapping(UserValidatorTest.class.getResourceAsStream("User-Validator.xml"));
		// ValidatorFactory factory = configuration.buildValidatorFactory();
		ValidatorFactory factory = Validation.byProvider(HibernateValidator.class).configure().buildValidatorFactory();
		Validator validator = factory.getValidator();
		Set<ConstraintViolation<User>> valideSet = validator.validate(user);
		if (valideSet != null && valideSet.size() > 0) {
			StringBuilder sb = new StringBuilder();
			for (ConstraintViolation<User> cv : valideSet) {
				sb.append(cv.getPropertyPath()).append(":").append(cv.getMessage()).append("\r\n");
			}
			System.out.println(sb.toString());
		}
	}
}
