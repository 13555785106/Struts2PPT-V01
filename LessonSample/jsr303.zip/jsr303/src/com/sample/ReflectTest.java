package com.sample;

import java.lang.reflect.Field;
import java.lang.reflect.InvocationTargetException;
import java.lang.reflect.Method;
import java.lang.reflect.Modifier;
import java.lang.reflect.ParameterizedType;
import java.lang.reflect.Type;
import java.util.List;
import java.util.Set;

public class ReflectTest {

	public static void main(String[] args) throws NoSuchFieldException, SecurityException, IllegalArgumentException,
			IllegalAccessException, NoSuchMethodException, InvocationTargetException {
		// System.out.println(ReflectTest.class.getName());
		// System.out.println(ReflectTest.class.getSimpleName());

		for (Field field : ReflectTest.class.getDeclaredFields()) {
			System.out.println(field.toGenericString());
			System.out.println(Modifier.isStatic(field.getModifiers()));
		}
		Field field = ReflectTest.class.getDeclaredField("param2");
		field.set(null, "肖俊峰");
		System.out.println(field.get(null));
		Method method = ReflectTest.class.getDeclaredMethod("func2", String.class, String.class);
		System.out.println(method.getReturnType());
		for (Type type : method.getGenericParameterTypes()) {
			System.out.println(type);
		}
		method.invoke(null, "DDDD", "EEE");

		Type t = ReflectTest.class.getDeclaredField("list1").getGenericType();
		System.out.println(((ParameterizedType)t).getRawType());
		if (ParameterizedType.class.isAssignableFrom(t.getClass())) {
			for (Type t1 : ((ParameterizedType) t).getActualTypeArguments()) {
				System.out.println(((ParameterizedType)t1).getRawType());
				if (ParameterizedType.class.isAssignableFrom(t1.getClass())) {
					for (Type t2 : ((ParameterizedType) t1).getActualTypeArguments()) {
						System.out.println(((ParameterizedType)t2).getRawType());
					}
				}
			}
			System.out.println();
		}
		
	}

	@SuppressWarnings("unused")
	private String param1 = "abc";
	@SuppressWarnings("unused")
	private static List<Set<List<String>>> list1;
	@SuppressWarnings("unused")
	private static String param2 = "def";

	public void func1() {
	}

	public static void func2(String p1, String p2) {
		System.out.println(p1 + "-" + p2);
	}

}
