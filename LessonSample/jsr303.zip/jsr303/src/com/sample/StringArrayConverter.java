package com.sample;

import java.util.Arrays;

import org.apache.commons.beanutils.Converter;

public class StringArrayConverter implements Converter {

	@SuppressWarnings("unchecked")
	@Override
	public <T> T convert(Class<T> type, Object value) {
		System.out.println("[StringArrayConverter]");
		if(type==String.class) {
			return (T)Arrays.asList(value).toString();
		}
		return null;
	}

}
