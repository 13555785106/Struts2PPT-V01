package com.sample;

public interface Dao<T> {

	public void save(T entity);
}
