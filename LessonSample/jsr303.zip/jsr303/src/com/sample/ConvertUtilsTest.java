package com.sample;

import java.util.HashMap;
import java.util.Map;

import org.apache.commons.beanutils.BeanUtils;
import org.apache.commons.beanutils.ConvertUtils;

public class ConvertUtilsTest {

	public static void main(String[] args) throws NoSuchFieldException, SecurityException, IllegalArgumentException, IllegalAccessException {
		Map<String, String> userMap = new HashMap<String, String>();
		userMap.put("account", " sa ");
		userMap.put("passwd", " 123 ");
		userMap.put("salary", "6321.98");
		userMap.put("birthday", "1973-10-11");
		userMap.put("hobbies","足球,篮球,排球");

		User user = new User();
		for (Map.Entry<String, String> entry : userMap.entrySet()) {
			try {
				BeanUtils.setProperty(user, entry.getKey(), entry.getValue());
			}catch(Exception e) {
				e.printStackTrace();
			}
		}
		System.out.println(user);
		
		
		/*ConverterFacade cf = (ConverterFacade)ConvertUtils.lookup(java.sql.Date.class);
		System.out.println(cf.getClass().getName());
		Field field = cf.getClass().getDeclaredField("converter");
		field.setAccessible(true);
		SqlDateConverter sdc = (SqlDateConverter)field.get(cf);
		sdc.setPatterns(new String[]{"yyyy大家/MM/dd","yyyy年MM月dd日"});
		Date date = new Date(new java.util.Date().getTime());
		
		System.out.println(ConvertUtils.convert(date, String.class));
		System.out.println(ConvertUtils.convert("2018年01月01日", java.sql.Date.class));*/
		//ConvertUtils.register(new StringConverter(), String.class);
		//ConvertUtils.register(new StringArrayConverter(), String[].class);	
		//System.out.println(ConvertUtils.convert(new String[] {"123","456","789"},String.class));
		
		
		/*ConvertUtils.register(new CnSqlDateConverter(), java.sql.Date.class);
		ConvertUtils.register(new ArrayConverter(CnSqlDateConverter[].class,new CnSqlDateConverter(),8), java.sql.Date[].class);
		
		Date date = new Date(new java.util.Date().getTime());
		
		System.out.println(ConvertUtils.convert(date, String.class));
		System.out.println(ConvertUtils.convert("2018年01月01日", java.sql.Date.class));
		
		
		
		for(Object obj : (Object[])ConvertUtils.convert(new String[] {"2018年01月01日","2018年02月02日"}, java.sql.Date.class)) {
			System.out.println(obj);
		}
		
		for(Object obj : (Object[])ConvertUtils.convert(new Date[] {new Date(new java.util.Date().getTime()),new Date(new java.util.Date().getTime())}, String[].class)) {
			System.out.println(obj);
		}*/
		/*Map<String, Object> userMap = new HashMap<String, Object>();
		userMap.put("account", "sa");
		userMap.put("passwd", "123");
		userMap.put("salary", "6321.98");
		userMap.put("birthday", "1973-10-11");
		userMap.put("hobbies",Arrays.asList(new String[] {"足球","篮球","排球"}));

		User user = new User();

		for (Map.Entry<String, Object> entry : userMap.entrySet()) {
			try {
				BeanUtils.setProperty(user, entry.getKey(), entry.getValue());
			}catch(Exception e) {
				e.printStackTrace();
			}
		}

		System.out.println(user);*/
		/*for(PropertyDescriptor pd :PropertyUtils.getPropertyDescriptors(User.class)) {
			System.out.println(pd.getName());
		}*/
	}

}
