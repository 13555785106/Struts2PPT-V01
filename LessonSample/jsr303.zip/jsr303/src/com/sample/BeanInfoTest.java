package com.sample;

import java.beans.BeanInfo;
import java.beans.IntrospectionException;
import java.beans.Introspector;
import java.beans.PropertyDescriptor;

public class BeanInfoTest {

	public static void main(String[] args) {
		BeanInfo bi = null;
		try {
			bi = Introspector.getBeanInfo(User.class);
		} catch (IntrospectionException e) {
			e.printStackTrace();
		}
		if (bi != null) {
			for (PropertyDescriptor pd : bi.getPropertyDescriptors()) {
				String propName = pd.getName();
				Class<?> propType = pd.getPropertyType();
				System.out.println(propType);
				System.out.println(propName + "=" + (propType.getComponentType() == null ? "null" : propType.getComponentType().getName()) + " " + propType.isArray());
			}
		}

	}

}
