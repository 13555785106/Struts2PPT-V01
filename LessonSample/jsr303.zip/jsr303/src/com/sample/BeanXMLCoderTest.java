package com.sample;

import java.beans.XMLDecoder;
import java.beans.XMLEncoder;
import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.FileOutputStream;
import java.lang.reflect.Field;
import java.lang.reflect.Method;
import java.util.Date;
import java.util.HashMap;
import java.util.Map;
import org.apache.commons.beanutils.BeanUtils;
import org.apache.commons.beanutils.ConvertUtils;

public class BeanXMLCoderTest {

	public static void main(String[] args)
			throws NoSuchFieldException, SecurityException, IllegalArgumentException, IllegalAccessException {

		Map<String, Object> userMap = new HashMap<String, Object>();
		userMap.put("account", "sa");
		userMap.put("passwd", "123");
		userMap.put("sex", "男");
		userMap.put("salary", 3000);
		userMap.put("birthday", new Date());
		userMap.put("hobbies", new String[] {"足球","篮球","排球"});
		User user = new User();
		for (Map.Entry<String, Object> entry : userMap.entrySet()) {
			try {
				BeanUtils.setProperty(user, entry.getKey(), entry.getValue());
			} catch (Exception e) {
				e.printStackTrace();
			}
		}
		System.out.println(user);
		for (String str : (String[]) ConvertUtils.convert("沈阳,长春,哈尔滨", String[].class))
			System.out.println(str);
		System.out.println("-----getDeclaredFields()");
		for (Field field : User.class.getDeclaredFields())
			System.out.println(field.getName());
		System.out.println("-----getDeclaredMethods()");
		for (Method method : User.class.getDeclaredMethods())
			System.out.println(method.getName());
		XMLEncoder xmlEncoder = null;
		try {
			xmlEncoder = new XMLEncoder(new FileOutputStream("user.xml"));
			xmlEncoder.writeObject(user);
		} catch (FileNotFoundException e) {
			e.printStackTrace();
		}finally {
			if(xmlEncoder != null)
				xmlEncoder.close();
		}
		XMLDecoder xmlDecoder = null;
		try {
			xmlDecoder = new XMLDecoder(new FileInputStream("user.xml"));
			System.out.println(xmlDecoder.readObject());
		} catch (FileNotFoundException e) {
			e.printStackTrace();
		}finally {
			if(xmlDecoder != null)
				xmlDecoder.close();
		}		
	}
}
