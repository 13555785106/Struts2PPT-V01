package com.sample;

public class StudentDao extends DaoImpl<String> {
	public static void main(String[] args) {
		DaoImpl dao = new StudentDao();
		//System.out.println(dao.getClass());
		dao.save(null);
		
		DaoImpl<Double> di = new DaoImpl<Double>();
		di.save(null);
	}

}
