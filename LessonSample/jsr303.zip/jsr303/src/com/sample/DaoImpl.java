package com.sample;

import java.lang.reflect.ParameterizedType;

public class DaoImpl<T> implements Dao<T> {

	public DaoImpl() {
		// TODO Auto-generated constructor stub
	}

	@Override
	public void save(T entity) {
		ParameterizedType pt = (ParameterizedType) this.getClass().getGenericSuperclass();
		Class clzz = (Class) pt.getActualTypeArguments()[0];
		System.out.println("Class:" + clzz);
	}

}
