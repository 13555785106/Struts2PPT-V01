package com.sample;

import org.apache.commons.beanutils.ConversionException;
import org.apache.commons.beanutils.Converter;
import java.sql.Date;
import java.text.ParseException;
import java.text.SimpleDateFormat;

public class CnSqlDateConverter implements Converter {
	SimpleDateFormat sdf = new SimpleDateFormat("yyyy年MM月dd日");

	@Override
	public <T> T convert(Class<T> type, Object value) {
		System.out.println("["+value+"]");
		if(value == null)
			return null;
		if(type == java.sql.Date.class) {
			return convertToDate(type, value);
		}else if(type == String.class) {
			return type.cast(convertToString(type, value));
		}
		 throw new ConversionException(value.getClass().getName() + "不能转换为" + type.getName());
	}


	public <T> T convertToDate(Class<T> type, Object value){
        if(value instanceof String){
            String dateStr = (String)value;
            try {
                Date d =new Date( sdf.parse(dateStr).getTime());
                return  type.cast(d);
            } catch (ParseException e) {
                e.printStackTrace();
                return null;
            }
        }else if(value instanceof Date){
            return type.cast(value);
        }
        throw new ConversionException(value.getClass().getName() + "不能转换为" + type.getName());
    }

    public <T>String convertToString(Class<T> type, Object value){
        if(value instanceof Date){
            return sdf.format(Date.class.cast(value));
        }
        return value.toString();
    }
}
